#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @className: ${NAME}
 * @description: TODO
 * @author: zyd
 * @date: ${DATE} ${TIME}
 * @version: 1.0
 */
public class ${NAME} {
}
